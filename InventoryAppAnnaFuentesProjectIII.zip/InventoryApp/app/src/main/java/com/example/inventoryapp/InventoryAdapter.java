package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    public interface ItemActions {
        void onPlus(InventoryItem item);
        void onMinus(InventoryItem item);
        void onDelete(InventoryItem item);
    }

    private final ArrayList<InventoryItem> items;
    private final ItemActions actions;

    public InventoryAdapter(ArrayList<InventoryItem> items, ItemActions actions) {
        this.items = items;
        this.actions = actions;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_inventory_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        InventoryItem item = items.get(position);

        h.tvName.setText(item.name);
        h.tvQty.setText(String.valueOf(item.qty));

        h.btnPlus.setOnClickListener(v -> actions.onPlus(item));
        h.btnMinus.setOnClickListener(v -> actions.onMinus(item));
        h.btnDelete.setOnClickListener(v -> actions.onDelete(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvQty;
        View btnMinus, btnPlus, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvRowItemName);
            tvQty = itemView.findViewById(R.id.tvRowQty);

            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}