package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class InventoryRepository {

    private final InventoryDbHelper dbHelper;

    public InventoryRepository(Context context) {
        dbHelper = new InventoryDbHelper(context);
    }

    // ---------- USERS ----------
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryDbHelper.COL_USERNAME, username);
        values.put(InventoryDbHelper.COL_PASSWORD, password);

        long result = db.insert(InventoryDbHelper.TABLE_USERS, null, values);
        return result != -1; // -1 means failure (like duplicate username)
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String selection = InventoryDbHelper.COL_USERNAME + "=? AND " + InventoryDbHelper.COL_PASSWORD + "=?";
        String[] args = { username, password };

        Cursor cursor = db.query(
                InventoryDbHelper.TABLE_USERS,
                new String[]{InventoryDbHelper.COL_USER_ID},
                selection,
                args,
                null,
                null,
                null
        );

        boolean valid = cursor.moveToFirst();
        cursor.close();
        return valid;
    }

    // ---------- INVENTORY CRUD ----------
    public long addItem(String name, int qty) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDbHelper.COL_ITEM_NAME, name);
        values.put(InventoryDbHelper.COL_ITEM_QTY, qty);
        return db.insert(InventoryDbHelper.TABLE_ITEMS, null, values);
    }

    public ArrayList<InventoryItem> getAllItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        ArrayList<InventoryItem> items = new ArrayList<>();

        Cursor cursor = db.query(
                InventoryDbHelper.TABLE_ITEMS,
                null,
                null,
                null,
                null,
                null,
                InventoryDbHelper.COL_ITEM_NAME + " COLLATE NOCASE ASC"
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryDbHelper.COL_ITEM_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDbHelper.COL_ITEM_NAME));
            int qty = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDbHelper.COL_ITEM_QTY));
            items.add(new InventoryItem(id, name, qty));
        }

        cursor.close();
        return items;
    }

    public boolean updateQty(long id, int newQty) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDbHelper.COL_ITEM_QTY, newQty);

        int rows = db.update(
                InventoryDbHelper.TABLE_ITEMS,
                values,
                InventoryDbHelper.COL_ITEM_ID + "=?",
                new String[]{ String.valueOf(id) }
        );
        return rows > 0;
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rows = db.delete(
                InventoryDbHelper.TABLE_ITEMS,
                InventoryDbHelper.COL_ITEM_ID + "=?",
                new String[]{ String.valueOf(id) }
        );
        return rows > 0;
    }
}