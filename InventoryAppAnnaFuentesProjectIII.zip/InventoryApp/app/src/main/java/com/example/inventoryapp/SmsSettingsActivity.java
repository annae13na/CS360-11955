package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsSettingsActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "app_prefs";
    public static final String KEY_SMS_ENABLED = "sms_enabled";

    private TextView tvPermissionStatus;
    private Switch switchEnableSms;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            tvPermissionStatus.setText("Permission Status: Granted");
                            Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                        } else {
                            tvPermissionStatus.setText("Permission Status: Denied");
                            // If permission denied, turn off switch so user sees it won't run
                            switchEnableSms.setChecked(false);
                            saveSmsEnabled(false);
                            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        Button btnRequest = findViewById(R.id.btnRequestSmsPermission);
        switchEnableSms = findViewById(R.id.switchEnableSms);

        // Load saved switch state
        switchEnableSms.setChecked(isSmsEnabledSaved());
        updatePermissionStatus();

        // Switch toggled by user
        switchEnableSms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // If user turns ON, ensure permission exists
                if (hasPermission()) {
                    saveSmsEnabled(true);
                    Toast.makeText(this, "SMS alerts enabled", Toast.LENGTH_SHORT).show();
                } else {
                    // Request permission; if denied, callback will turn it off
                    requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                }
            } else {
                saveSmsEnabled(false);
                Toast.makeText(this, "SMS alerts disabled", Toast.LENGTH_SHORT).show();
            }
        });

        // Button to request permission manually
        btnRequest.setOnClickListener(v -> {
            if (hasPermission()) {
                tvPermissionStatus.setText("Permission Status: Granted");
                Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            } else {
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });
    }

    private boolean hasPermission() {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void updatePermissionStatus() {
        tvPermissionStatus.setText(hasPermission()
                ? "Permission Status: Granted"
                : "Permission Status: Not granted");
    }

    private void saveSmsEnabled(boolean enabled) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_SMS_ENABLED, enabled).apply();
    }

    private boolean isSmsEnabledSaved() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_SMS_ENABLED, false);
    }
}