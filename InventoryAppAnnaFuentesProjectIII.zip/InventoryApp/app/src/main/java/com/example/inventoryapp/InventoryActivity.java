package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private InventoryRepository repo;
    private ArrayList<InventoryItem> items;
    private InventoryAdapter adapter;

    // Must match SmsSettingsActivity
    private static final String PREFS_NAME = "app_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Button that opens the SMS Settings screen
        Button btnSmsSettings = findViewById(R.id.btnSmsSettings);
        btnSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsSettingsActivity.class);
            startActivity(intent);
        });

        repo = new InventoryRepository(this);

        RecyclerView rvInventory = findViewById(R.id.rvInventory);
        rvInventory.setLayoutManager(new LinearLayoutManager(this));

        items = repo.getAllItems();

        adapter = new InventoryAdapter(items, new InventoryAdapter.ItemActions() {
            @Override
            public void onPlus(InventoryItem item) {
                int newQty = item.qty + 1;
                repo.updateQty(item.id, newQty);
                item.qty = newQty;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onMinus(InventoryItem item) {
                int newQty = Math.max(0, item.qty - 1);
                repo.updateQty(item.id, newQty);
                item.qty = newQty;
                adapter.notifyDataSetChanged();

                // Trigger SMS only when it hits 0
                if (newQty == 0) {
                    maybeSendLowStockSms(item.name);
                }
            }

            @Override
            public void onDelete(InventoryItem item) {
                repo.deleteItem(item.id);
                items.remove(item);
                adapter.notifyDataSetChanged();
            }
        });

        rvInventory.setAdapter(adapter);

        EditText etItemName = findViewById(R.id.etItemName);
        EditText etItemQty = findViewById(R.id.etItemQty);
        Button btnAddItem = findViewById(R.id.btnAddItem);

        btnAddItem.setOnClickListener(v -> {
            String name = etItemName.getText().toString().trim();
            String qtyStr = etItemQty.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Enter item name and quantity.", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty;
            try {
                qty = Integer.parseInt(qtyStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
                return;
            }

            long id = repo.addItem(name, qty);
            if (id != -1) {
                items.clear();
                items.addAll(repo.getAllItems());
                adapter.notifyDataSetChanged();
                etItemName.setText("");
                etItemQty.setText("");
            }
        });
    }

    /**
     * Sends SMS alert if:
     * 1) User enabled SMS in settings (SharedPreferences)
     * 2) Permission SEND_SMS is granted
     * If not, the app continues normally (no crash).
     */
    private void maybeSendLowStockSms(String itemName) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean smsEnabled = prefs.getBoolean(KEY_SMS_ENABLED, false);

        if (!smsEnabled) return;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission denied -> do nothing (app still works)
            return;
        }

        // NOTE: Emulators often won't send real SMS.
        // This is mainly to prove your permission + trigger logic works.
        String phoneNumber = "5551234567";
        String message = "Alert: " + itemName + " is out of stock (0 left).";

        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low-stock SMS attempted.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed (emulator/device limitation).", Toast.LENGTH_SHORT).show();
        }
    }
}